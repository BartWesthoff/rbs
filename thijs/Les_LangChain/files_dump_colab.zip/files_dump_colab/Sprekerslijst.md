# Tweede Kamer
## DER STATEN-GENERAAL
### SPREKERSLIJST
**Maandag 14 april 2025**

#### Tweeminutendebat Sturing in het funderend onderwijs (CD 12/2)

| # | Naam            | Fractie          | Spreektijd |
|---|-----------------|------------------|------------|
| 1 | A. J. Soepboer  | NSC              | 2 min      |
| 2 | A. Pijpelink    | GroenLinks-PvdA  | 2 min      |
| 3 | I. Rooderkerk   | D66              | 2 min      |
| 4 | A. Kisteman     | VVD              | 2 min      |
| 5 | H.M. Krul       | CDA              | 2 min      |

---

**Afkortingen en partijen:**
- **PVV**: Partij voor de Vrijheid
- **GroenLinks-PvdA**
- **VVD**: Volkspartij voor Vrijheid en Democratie
- **NSC**: Nieuw Sociaal Contract
- **D66**: Democraten 66
- **BBB**
- **CDA**: Christen-Democratisch Appèl
- **SP**: Socialistische Partij
- **DENK**
- **PvdD**: Partij voor de Dieren
- **FVD**: Forum voor Democratie
- **SGP**: Staatkundig Gereformeerde Partij
- **ChristenUnie**
- **Volt**
- **JA21**
